"""
Init module
"""
from .exceptions import InvalidCompilation
from .types import Type
