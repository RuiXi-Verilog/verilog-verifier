"""
Crytic Compile Exceptions
"""


class InvalidCompilation(Exception):
    """
    Invalid compilation exception
    """

    # pylint: disable=unnecessary-pass
    pass
