---
title: Math
sections:
  - title: Libraries
    contracts:
      - SafeMath
      - Math
---

These are math-related utilities.
