
from .variable_declaration import VariableDeclarationSolc
from slither.core.variables.local_variable import LocalVariable

class LocalVariableSolc(VariableDeclarationSolc, LocalVariable): pass
