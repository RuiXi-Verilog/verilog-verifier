from .variable import Variable
from slither.core.children.child_contract import ChildContract

class StateVariable(ChildContract, Variable): pass
