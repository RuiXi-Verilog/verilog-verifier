from .variable import Variable
from slither.core.children.child_event import ChildEvent

class EventVariable(ChildEvent, Variable): pass

