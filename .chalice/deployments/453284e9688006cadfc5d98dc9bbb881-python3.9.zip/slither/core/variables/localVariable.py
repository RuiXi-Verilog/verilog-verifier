from .variable import Variable
from slither.core.children.child_function import ChildFunction

class LocalVariable(ChildFunction, Variable): pass

