from .variable import Variable
from slither.core.children.child_structure import ChildStructure

class StructureVariable(ChildStructure, Variable): pass

