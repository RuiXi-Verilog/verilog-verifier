"""
    Modifier module
"""
from .function import Function

class Modifier(Function): pass

