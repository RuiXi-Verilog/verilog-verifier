from slither.core.expressions.expression import Expression
from slither.core.expressions.call_expression import CallExpression

class SuperCallExpression(CallExpression): pass
