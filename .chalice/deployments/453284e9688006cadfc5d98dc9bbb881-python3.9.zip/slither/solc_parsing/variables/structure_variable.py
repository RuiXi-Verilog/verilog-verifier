
from .variable_declaration import VariableDeclarationSolc
from slither.core.variables.structure_variable import StructureVariable

class StructureVariableSolc(VariableDeclarationSolc, StructureVariable): pass
