class DetectorClassification:
    LOW = 0
    MEDIUM = 1
    HIGH = 2
