from slither.exceptions import SlitherException


class FormatImpossible(SlitherException):
    pass


class FormatError(SlitherException):
    pass
