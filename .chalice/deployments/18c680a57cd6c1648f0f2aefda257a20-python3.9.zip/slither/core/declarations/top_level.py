from slither.core.source_mapping.source_mapping import SourceMapping


class TopLevel(SourceMapping):
    pass
