from slither.core.expressions.call_expression import CallExpression


class SuperCallExpression(CallExpression):
    pass
