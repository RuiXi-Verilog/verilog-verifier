Contract modules for simple authorization and access control mechanisms.

For more complex needs see [Access](access).
